<?php

class Hello
{
    public function sayHi()
    {
        return 'hello';
    }

    public static function sayBye()
    {
        return 'goodbye';
    }
}
